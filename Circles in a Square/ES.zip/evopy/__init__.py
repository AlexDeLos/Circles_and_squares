"""The evopy evolutionary strategy algorithm package."""
from evopy.evopy import EvoPy
from evopy.strategy import Strategy
from evopy.progress_report import ProgressReport
