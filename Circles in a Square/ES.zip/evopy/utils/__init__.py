"""The evopy evolutionary strategy algorithm package utility package."""
from .random import random_with_seed
