//
// Created by Renzo on 12-6-2020.
//

#ifndef PROJECT_ELEMENTARY_H
#define PROJECT_ELEMENTARY_H

#include <stdlib.h>
#include <stdio.h>

void *Malloc( long size );

#endif //PROJECT_ELEMENTARY_H
