//
// Created by Renzo on 12-6-2020.
//

#ifndef PROJECT_FITNESS_H
#define PROJECT_FITNESS_H

short betterFitness( double objective_value_x, double constraint_value_x, double objective_value_y, double constraint_value_y );

#endif //PROJECT_FITNESS_H
